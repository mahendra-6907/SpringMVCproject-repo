package com.springmvc.membership;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class MemberDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	public int saveMember(Member memberPojo) {
		String sql = "insert into membership(name, membershipplan, location) values ('" +  memberPojo.getName() + "','" + memberPojo.getMembershipPlan() + "', '" + memberPojo.getLocation() + "')";
		return jdbcTemplate.update(sql);
		
		
		
	}


	public List<Member> listMembers() {
		
		return jdbcTemplate.query("select * from membership", new RowMapper<Member>() {

			@Override
			public Member mapRow(ResultSet resultset, int row) throws SQLException {
				// TODO Auto-generated method stub
				Member mp = new Member();
				mp.setMembershipId(resultset.getInt(1));
				mp.setName(resultset.getString(2));
				mp.setMembershipPlan(resultset.getString(3));
				mp.setLocation(resultset.getString(4));
				return mp;
			}
		
		});
		
	}
/*
	public EmployeePojo getEmployeeById(int id) {
		// TODO Auto-generated method stub
		String sql = "select *  from employee where id=?"; 
		return jdbcTemplate.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<EmployeePojo>(EmployeePojo.class));
	}


	public int updateEmployee(EmployeePojo employee) {
		// TODO Auto-generated method stub
		System.out.println("In DAO class for updating employee: " + employee.getId() + " " + employee.getName() + " " + employee.getSalary() + " " + employee.getDesignation());
		//update employee set name='omana', salary=4000, designation='developer' where id=1
		String sql = "update employee set name='"+employee.getName()+"',salary=" + employee.getSalary()+",designation='" + employee.getDesignation() + "' where id="+ employee.getId()+"";
		System.out.println(sql);
		int result = jdbcTemplate.update(sql);
		System.out.println(result);
		return result;
		
	}
	
*/

}
