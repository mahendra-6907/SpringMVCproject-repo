package com.springmvc.membership;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MembershipContreoller {
	
	@Autowired
	private MemberDao memberDao;
	
	@RequestMapping("/index")
	public String getLandingPage() {
		return "welcome";
	}
	
	@RequestMapping(value = "/addMember", method = RequestMethod.GET)
	public ModelAndView addEmployee() {
		return new ModelAndView("register", "userform", new Member());
	}
	
	/*
	@RequestMapping("/index")
	public String landHomePage(Model m) {
		m.addAttribute("userform", new Member());
		return "register";
		
	}*/
	
	@RequestMapping(value = "/saveRegistration", method = RequestMethod.POST)
	public String saveRegistration(@Valid @ModelAttribute("userform") Member memberpojo,  BindingResult result) {
		//System.out.println(employeePojo.getName() + " " + employeePojo.getSalary() + " " + employeePojo.getDesignation());
		if(result.hasErrors())
			return "register";
		else
		{
			int numberOfRowsEffected = memberDao.saveMember(memberpojo);
			return "redirect:/listMembers";
		}
	}
	
	
	@RequestMapping(value = "/listMembers", method = RequestMethod.GET )
	public ModelAndView listEmployee() {
		List<Member> all = memberDao.listMembers();
		return new ModelAndView("listmembers", "allmembers", all);
		
	}
	
	
	@ModelAttribute("allmembershipplans")
	public List getMembershipPlan() {
		List allmembershipplans = new ArrayList();
		allmembershipplans.add("Premium");
		allmembershipplans.add("Standard");
		allmembershipplans.add("Free");
		
		return allmembershipplans;
	}

}
