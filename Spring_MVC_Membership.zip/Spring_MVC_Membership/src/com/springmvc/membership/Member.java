package com.springmvc.membership;

import javax.validation.constraints.NotEmpty;

public class Member {

	
	private int membershipId;
	@NotEmpty
	private String name;
	@NotEmpty
	private String membershipPlan;
	@NotEmpty
	private String location;
	
	public Member(int membershipId, String name, String membershipPlan, String location) {
		super();
		this.membershipId = membershipId;
		this.name = name;
		this.membershipPlan = membershipPlan;
		this.location = location;
	}
	
	public Member() {
	}

	public int getMembershipId() {
		return membershipId;
	}

	public void setMembershipId(int membershipId) {
		this.membershipId = membershipId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMembershipPlan() {
		return membershipPlan;
	}

	public void setMembershipPlan(String membershipPlan) {
		this.membershipPlan = membershipPlan;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	
	
	
}